package com.java;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@ComponentScan(basePackages = "com.java")
public class Beanconfig {
//    @Bean
//    @Scope("singleton")
//    public PlainTextWriter ptr(){
//        return new PlainTextWriter("abc", "last round before the switch!");
//    }


}
